package inxj.newsfeed.post.entity;public class Post {
}
