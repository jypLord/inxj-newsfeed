package inxj.newsfeed.post.entity;public enum Category {
}
