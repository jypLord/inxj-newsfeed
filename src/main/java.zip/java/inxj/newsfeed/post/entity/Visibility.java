package inxj.newsfeed.post.enum;

public enum Visibility {
}