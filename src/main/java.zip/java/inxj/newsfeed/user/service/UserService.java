package inxj.newsfeed.user.service;

import inxj.newsfeed.user.dto.request.SignUpRequest;
import inxj.newsfeed.user.dto.response.ProfileResponse;
import inxj.newsfeed.user.dto.response.SignUpResponse;
import inxj.newsfeed.user.entity.User;
import inxj.newsfeed.user.repository.UserRepository;

import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class UserService {
    private final UserRepository userRepository;

    //TODO: 이메일 인증.. 할 수도?
    public SignUpResponse signUp(SignUpRequest dto){
        User newbie = new User(dto.getEmail(),dto.getPassword(),
                dto.getUsername(), dto.getName(), dto.getBirthday(),
                dto.getGender(), dto.getPhoneNumber(), dto.getProfileImageUrl());

        userRepository.save(newbie);

        User isRealSignedUp = userRepository.findByUsername(dto.getUsername());

        return new SignUpResponse(isRealSignedUp.getEmail(), isRealSignedUp.getUsername());
    }
    public ProfileResponse viewProfile(Long id){
        //TODO: 전역 예외처리 논의하기
        User user = userRepository.findById(id).orElseThrow(() -> new UserNotFoundException("해당 유저 없음"));

        return new ProfileResponse(user.getProfileImageUrl(), user.getName(),user.getUsername() ,user.getEmail(), user.getBirthday(), user.getGender());
    }
}
