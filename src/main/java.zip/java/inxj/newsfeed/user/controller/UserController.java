package inxj.newsfeed.user.controller;

import inxj.newsfeed.user.dto.request.SignUpRequest;
import inxj.newsfeed.user.dto.response.ProfileResponse;
import inxj.newsfeed.user.dto.response.SignUpResponse;
import inxj.newsfeed.user.service.UserService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequiredArgsConstructor
public class UserController {
    private final UserService userService;

    @PostMapping(value = "/users")
    public ResponseEntity<SignUpResponse> signUp(@RequestBody @Valid SignUpRequest dto){

        return ResponseEntity.ok(userService.signUp(dto));
    }
    @GetMapping("/users/{id}")
    public ResponseEntity<?> viewProfile(@PathVariable Long id){

        return ResponseEntity.ok(userService.viewProfile(id));
    }
}
