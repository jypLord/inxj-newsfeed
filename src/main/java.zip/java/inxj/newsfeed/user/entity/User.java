package inxj.newsfeed.user.entity;


import baseEntity.BaseEntity;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Getter
@Entity
@NoArgsConstructor
public class User extends BaseEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(unique = true)
    private String email;

    private String password;

    @Column(unique = true)
    private String username;

    private String name;

    private LocalDateTime birthday;

    private String gender;

    @Column(unique = true)
    private String phoneNumber;

    private String profileImageUrl;

    private LocalDateTime deletedAt;

    // PK와 탈퇴시간 뺀 생성자
    public User(String email, String password, String username, String name, LocalDateTime birthday, String gender, String phoneNumber, String profileImageUrl){
        this.email = email;
        this.password = password;
        this.username = username;
        this.name = name;
        this.birthday=birthday;
        this.gender = gender;
        this.phoneNumber= phoneNumber;
        this.profileImageUrl = profileImageUrl;
    }

}