package inxj.newsfeed.user.dto.request;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Getter;

import java.time.LocalDateTime;


@Getter
@AllArgsConstructor
public class SignUpRequest{
    @Email
    private final String email;

    @Size(min=8)
    private final String password;

    @NotBlank
    private final String username;

    private final String name;

    private final LocalDateTime birthday;

    private final String gender;

    private final String phoneNumber;

    private final String profileImageUrl;
}
