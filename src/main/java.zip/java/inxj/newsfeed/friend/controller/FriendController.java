package inxj.newsfeed.friend.controller;

public class FriendController {
}
