package inxj.newsfeed.friend.service;

public class FriendService {
}
